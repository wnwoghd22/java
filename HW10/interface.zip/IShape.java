public interface IShape {
	public double calcPerimeter();
	public double calcArea();
}
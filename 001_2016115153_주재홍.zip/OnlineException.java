public class OnlineException extends GeometricException {
	public OnlineException() {
		super("3 points lie on a straight line.");
	}
}
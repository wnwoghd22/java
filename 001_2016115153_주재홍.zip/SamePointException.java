public class SamePointException extends GeometricException {
	public SamePointException() {
		super("The two points are the same.");
	}
}
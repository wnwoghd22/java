public class GeometricException extends Exception {
	public GeometricException(String s) {
		super(s);
	}
}